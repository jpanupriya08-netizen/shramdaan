# Shramdaan workspace

This repository contains the Shramdaan community resource and skill mapper, along
with the workspace packages it depends on.

## Run Shramdaan in VS Code

### Requirements

- Node.js 22.12 or newer
- pnpm 10 or newer
- Visual Studio Code

Open the extracted project folder (the folder containing `pnpm-workspace.yaml`)
in VS Code, then open a terminal at the project root.

Install dependencies:

```sh
pnpm install
```

Start the Shramdaan web app:

**Windows PowerShell**

```powershell
$env:PORT = "5173"
$env:BASE_PATH = "/"
pnpm --filter @workspace/shramdaan run dev
```

**macOS, Linux, or Git Bash**

```sh
PORT=5173 BASE_PATH=/ pnpm --filter @workspace/shramdaan run dev
```

Open the local address printed by Vite (usually `http://localhost:5173`).

To check the app:

```sh
pnpm --filter @workspace/shramdaan run typecheck
pnpm --filter @workspace/shramdaan run build
```

The offers currently use in-memory sample data. A page refresh resets changes
made during that session. Prices are displayed by the app; it does not collect
payments.
