import { useMemo, useState, type FormEvent } from 'react';
import { ArrowUpRight, Bookmark, CircleCheck, Clock3, MapPin, Plus, Search, Send, X } from 'lucide-react';
import './index.css';

type Kind = 'Resource' | 'Skill' | 'Time';
type ResourcePricingMode = 'Rent' | 'Sale';
const BOOK_CLASSIFICATIONS = ['Computer Science', 'Maths', 'Biology', 'Chemistry', 'Physics', 'Stories', 'Question Banks'] as const;
type BookClassification = (typeof BOOK_CLASSIFICATIONS)[number];
type Listing = { id: number; title: string; kind: Kind; category: string; description: string; location: string; availability: string; owner: string; initials: string; classification?: BookClassification; resourcePricingMode?: ResourcePricingMode; rentPerWeek?: number; salePrice?: number; hourlyRate?: number; featured?: boolean };
const seedListings: Listing[] = [
  { id: 1, title: 'Calculus III textbook set', kind: 'Resource', category: 'Books', classification: 'Maths', resourcePricingMode: 'Rent', rentPerWeek: 40, description: 'Stewart and solved papers from the last three semesters. Some honest pencil notes included.', location: 'Hostel Block C', availability: 'Available this week', owner: 'Ananya Rao', initials: 'AR', featured: true },
  { id: 2, title: 'Bike for campus errands', kind: 'Resource', category: 'Mobility', resourcePricingMode: 'Rent', rentPerWeek: 85, description: 'A sturdy single-speed, basket included. Borrow for a few hours or a whole weekend.', location: 'Lake Road', availability: 'Weekends', owner: 'Rohan Mehta', initials: 'RM' },
  { id: 3, title: 'Conversational Hindi practice', kind: 'Skill', category: 'Languages', hourlyRate: 60, description: 'Patient speaking partner for beginners. Chai and awkward pauses both welcome.', location: 'Library courtyard', availability: 'Tue + Thu evenings', owner: 'Maya Joseph', initials: 'MJ' },
  { id: 4, title: 'Arduino starter kit', kind: 'Resource', category: 'Projects', resourcePricingMode: 'Rent', rentPerWeek: 70, description: 'Uno board, jumper wires, LEDs and sensors. Great for a first tinkering session.', location: 'Innovation Lab', availability: 'After 4pm', owner: 'Dev Patel', initials: 'DP' },
  { id: 5, title: 'Proofread your scholarship essay', kind: 'Skill', category: 'Writing', hourlyRate: 90, description: 'I can help make the argument clearer without sanding off your voice.', location: 'Online or Block A', availability: 'Two slots open', owner: 'Sana Khan', initials: 'SK' },
  { id: 6, title: 'Two hours for moving boxes', kind: 'Time', category: 'A hand', hourlyRate: 50, description: 'Available Saturday morning to carry, sort or assemble flat-pack furniture.', location: 'North Gate', availability: 'Saturday morning', owner: 'Kabir Singh', initials: 'KS' },
  { id: 7, title: 'Watercolor supplies', kind: 'Resource', category: 'Creative', resourcePricingMode: 'Sale', salePrice: 65, description: 'Half-used paper pad, travel palette and two good brushes for sale.', location: 'Arts Building', availability: 'Pick up anytime', owner: 'Ishita Bose', initials: 'IB' },
];

const formatINR = (amount: number) => `₹${amount.toLocaleString('en-IN')}`;
const getListingPriceBadge = (listing: Listing) => {
  if (listing.kind !== 'Resource') return `Service · ${typeof listing.hourlyRate === 'number' ? `${formatINR(listing.hourlyRate)} / hour` : 'price not set'}`;
  if (listing.resourcePricingMode === 'Sale') return `Sale · ${typeof listing.salePrice === 'number' ? `${formatINR(listing.salePrice)} fixed` : 'price not set'}`;
  return `Rent · ${typeof listing.rentPerWeek === 'number' ? `${formatINR(listing.rentPerWeek)} / week` : 'price not set'}`;
};
const getListingPriceLabel = (listing: Listing) => listing.kind !== 'Resource'
  ? 'Service charge per hour'
  : listing.resourcePricingMode === 'Sale' ? 'Fixed sale price' : 'Rent per week';
const getListingPriceValue = (listing: Listing) => listing.kind !== 'Resource'
  ? `${typeof listing.hourlyRate === 'number' ? formatINR(listing.hourlyRate) : 'Price not set'} / hour`
  : listing.resourcePricingMode === 'Sale'
    ? `${typeof listing.salePrice === 'number' ? formatINR(listing.salePrice) : 'Price not set'} fixed`
    : `${typeof listing.rentPerWeek === 'number' ? formatINR(listing.rentPerWeek) : 'Price not set'} / week`;

function App() {
  const [listings, setListings] = useState(seedListings);
  const [query, setQuery] = useState('');
  const [category, setCategory] = useState('All');
  const [onlyAvailable, setOnlyAvailable] = useState(false);
  const [classificationFilter, setClassificationFilter] = useState('All');
  const [saved, setSaved] = useState<Set<number>>(new Set());
  const [selected, setSelected] = useState<Listing | null>(null);
  const [showForm, setShowForm] = useState(false);
  const [toast, setToast] = useState('');
  const [form, setForm] = useState({ title: '', kind: 'Resource' as Kind, category: 'Books', classification: 'Maths' as BookClassification, resourcePricingMode: 'Rent' as ResourcePricingMode, priceAmount: '', description: '', location: '', availability: '', owner: '' });
  const categories = useMemo(() => ['All', ...Array.from(new Set(listings.map((item) => item.category)))], [listings]);
  const isBookForm = form.kind === 'Resource' && /\b(books?|textbooks?)\b/i.test(form.category);
  const filtered = useMemo(() => listings.filter((item) => {
    const text = `${item.title} ${item.description} ${item.location} ${item.owner} ${item.classification ?? ''}`.toLowerCase();
    const q = query.toLowerCase().trim();
    return (!q || text.includes(q)) && (category === 'All' || item.category === category) && (classificationFilter === 'All' || item.classification === classificationFilter) && (!onlyAvailable || item.availability.toLowerCase().includes('available') || item.availability.toLowerCase().includes('open'));
  }), [category, classificationFilter, listings, onlyAvailable, query]);
  const showToast = (message: string) => { setToast(message); window.setTimeout(() => setToast(''), 2800); };
  const toggleSaved = (id: number) => setSaved((current) => {
    const next = new Set(current);
    if (next.has(id)) { next.delete(id); showToast('Removed from your saved board.'); } else { next.add(id); showToast('Saved. We’ll keep it close.'); }
    return next;
  });
  const updateForm = (field: keyof typeof form, value: string) => setForm((current) => ({ ...current, [field]: value }));
  const submitListing = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (!form.title.trim() || !form.location.trim() || !form.owner.trim()) return;
    const priceAmount = Number(form.priceAmount);
    const isFixedSale = form.kind === 'Resource' && form.resourcePricingMode === 'Sale';
    if (!form.priceAmount.trim() || !Number.isFinite(priceAmount) || (isFixedSale ? priceAmount <= 0 : priceAmount < 40 || priceAmount > 100)) {
      showToast(isFixedSale ? 'Enter a fixed sale price greater than ₹0.' : form.kind === 'Resource' ? 'Weekly rent must be between ₹40 and ₹100.' : 'Hourly service charges must be between ₹40 and ₹100.');
      return;
    }
    const owner = form.owner.trim();
    const pricingFields = form.kind === 'Resource'
      ? form.resourcePricingMode === 'Sale'
        ? { resourcePricingMode: 'Sale' as const, salePrice: priceAmount }
        : { resourcePricingMode: 'Rent' as const, rentPerWeek: priceAmount }
      : { hourlyRate: priceAmount };
    setListings((current) => [{
      id: Date.now(), title: form.title.trim(), kind: form.kind, category: form.category.trim() || 'Other',
      classification: isBookForm ? form.classification : undefined,
      ...pricingFields,
      description: form.description.trim() || 'A useful thing, ready to find a good home.', location: form.location.trim(),
      availability: form.availability.trim() || 'Let’s coordinate', owner, initials: owner.split(/\s+/).map((part) => part[0]).join('').slice(0, 2).toUpperCase(),
    }, ...current]);
    setShowForm(false);
    setForm({ title: '', kind: 'Resource', category: 'Books', classification: 'Maths', resourcePricingMode: 'Rent', priceAmount: '', description: '', location: '', availability: '', owner: '' });
    showToast('Your listing is live on the neighborhood board.');
  };
  const scrollTo = (id: string) => document.getElementById(id)?.scrollIntoView({ behavior: 'smooth' });

  return <div className="app-shell">
    <header className="topbar">
      <button className="brand" onClick={() => scrollTo('board')} data-testid="button-brand-home"><span className="brand-mark">श</span><span><span className="brand-name">shramdaan</span><span className="brand-sub">give a little · find a lot</span></span></button>
      <nav className="topbar-nav" aria-label="Main navigation"><button onClick={() => scrollTo('board')} data-testid="button-nav-board">The board</button><button onClick={() => scrollTo('how-it-works')} data-testid="button-nav-java">How it works</button></nav>
      <button className="header-action" onClick={() => setShowForm(true)} data-testid="button-open-listing"><Plus size={15} /> Add a listing</button>
    </header>
    <main>
      <section className="hero" aria-labelledby="hero-title">
        <div><div className="eyebrow"><span className="eyebrow-dot" /> Your corner of campus, made useful</div><h1 id="hero-title">Put what you know <em>to work.</em></h1><p className="hero-copy">A living noticeboard for the things that make a day easier: a spare book, a borrowed bike, a patient explanation, or two good hours.</p></div>
        <div className="hero-note"><div className="note-card"><div className="note-card-top"><span>Today on the board</span><CircleCheck size={15} /></div><h2>Small acts. Properly matched.</h2><div className="note-stats"><div className="note-stat"><strong>{listings.length}</strong><span>active offers</span></div><div className="note-stat"><strong>{new Set(listings.map((item) => item.location)).size}</strong><span>local spots</span></div><div className="note-stat"><strong>3</strong><span>ways to help</span></div></div></div></div>
      </section>
      <section className="board" id="board" aria-labelledby="board-title">
        <div className="board-head"><div><p className="section-kicker">The neighborhood board</p><h2 className="board-title" id="board-title">Find something useful.</h2></div><p className="board-count" data-testid="text-listing-count">{filtered.length} {filtered.length === 1 ? 'offer' : 'offers'} showing</p></div>
        <div className="filters"><div className="search-wrap"><Search size={17} /><input value={query} onChange={(event) => setQuery(event.target.value)} placeholder="Search books, skills, places..." aria-label="Search listings" data-testid="input-search-listings" /></div><select className="filter-select" value={category} onChange={(event) => setCategory(event.target.value)} aria-label="Filter by category" data-testid="select-category">{categories.map((option) => <option key={option}>{option}</option>)}</select><select className="filter-select" value={classificationFilter} onChange={(event) => setClassificationFilter(event.target.value)} aria-label="Filter by book classification" data-testid="select-book-classification"><option value="All">All book subjects</option>{BOOK_CLASSIFICATIONS.map((option) => <option key={option} value={option}>{option}</option>)}</select><button className={`available-toggle ${onlyAvailable ? 'active' : ''}`} onClick={() => setOnlyAvailable((value) => !value)} data-testid="button-toggle-available"><span className="toggle-dot" /> {onlyAvailable ? 'Available only' : 'All availability'}</button></div>
        <div className="resource-grid">
          {filtered.length ? filtered.map((item, index) => <article className={`resource-card ${item.featured ? 'featured' : ''}`} key={item.id} style={{ animationDelay: `${Math.min(index, 8) * 45}ms` }} data-testid={`card-listing-${item.id}`}>
            <div className="card-top"><div className="card-labels"><span className={`tag ${item.kind === 'Skill' ? 'skill' : item.kind === 'Time' ? 'time' : ''}`}>{item.kind} · {item.category}</span>{item.classification && <span className="book-subject">{item.classification}</span>}</div><div className="card-actions-top"><span className="pricing-badge">{getListingPriceBadge(item)}</span><button className={`bookmark ${saved.has(item.id) ? 'active' : ''}`} onClick={() => toggleSaved(item.id)} aria-label={`Save ${item.title}`} data-testid={`button-save-${item.id}`}><Bookmark size={17} fill={saved.has(item.id) ? 'currentColor' : 'none'} /></button></div></div>
            <h3>{item.title}</h3><p className="resource-muted">{item.description}</p><div className="card-bottom"><div><div className="location"><MapPin size={13} /> {item.location}</div><div className="owner"><span className="avatar">{item.initials}</span> {item.owner} · <Clock3 size={11} /> {item.availability}</div></div><button className="card-action" onClick={() => setSelected(item)} data-testid={`button-view-${item.id}`}>View offer <ArrowUpRight size={13} /></button></div>
          </article>) : <div className="empty-state" data-testid="empty-listings"><Search size={27} /><h3>Nothing hiding here.</h3><p>Try a wider search, or be the first person to offer it.</p><button className="button-primary" onClick={() => { setQuery(''); setCategory('All'); setClassificationFilter('All'); setOnlyAvailable(false); }} data-testid="button-clear-filters">Clear filters</button></div>}
        </div>
      </section>
      <section className="how-section" id="how-it-works" aria-labelledby="how-title">
        <div><p className="section-kicker">Under the noticeboard</p><h2 id="how-title">A little Java, <span>a lot of useful.</span></h2><p className="how-intro">Shramdaan is also a Java syllabus demonstration. Each listing is a Resource object; a simple array holds the board, loops visit each one, and conditions help you find the right fit.</p></div>
        <div className="java-card"><div className="java-card-head"><span>Resource.java</span><span>the small idea</span></div><pre className="java-code"><code><span className="kw">class</span> <span className="type">Resource</span> &#123;<br />  String title;<br />  String kind;<br />  String location;<br />  <span className="kw">boolean</span> available;<br /><br />  <span className="kw">void</span> showIfUseful() &#123;<br />    <span className="kw">if</span> (available) &#123;<br />      System.out.println(title);<br />    &#125;<br />  &#125;<br />&#125;</code></pre><div className="java-legend"><div><strong>01</strong><span>Class<br />one shape for every offer</span></div><div><strong>02</strong><span>Array<br />the shared board</span></div><div><strong>03</strong><span>Loop + if<br />a helpful filter</span></div></div></div>
      </section>
    </main>
    <footer className="footer-strip"><span>Built for the people two doors away.</span><span>Java foundations · community edition</span></footer>

    {showForm && <div className="modal-backdrop" role="presentation" onMouseDown={(event) => { if (event.target === event.currentTarget) setShowForm(false); }}><form className="modal" onSubmit={submitListing} aria-label="Add a listing">
      <div className="modal-head"><div><p className="section-kicker">Put something useful out there</p><h2>Add a listing</h2></div><button type="button" className="modal-close" onClick={() => setShowForm(false)} aria-label="Close form" data-testid="button-close-form"><X size={16} /></button></div>
      <div className="form-grid">
        <div className="form-field full"><label htmlFor="listing-title">What are you sharing?</label><input id="listing-title" required value={form.title} onChange={(event) => updateForm('title', event.target.value)} placeholder="e.g. Intro to Python tutoring" data-testid="input-listing-title" /></div>
        <div className="form-field"><label htmlFor="listing-kind">This is a</label><select id="listing-kind" value={form.kind} onChange={(event) => updateForm('kind', event.target.value as Kind)} data-testid="select-listing-kind"><option>Resource</option><option>Skill</option><option>Time</option></select></div>
        <div className="form-field"><label htmlFor="listing-category">Category</label><input id="listing-category" value={form.category} onChange={(event) => updateForm('category', event.target.value)} placeholder="Books, care, making..." data-testid="input-listing-category" /></div>
        {isBookForm && <div className="form-field full"><label htmlFor="listing-classification">Book classification</label><select id="listing-classification" value={form.classification} onChange={(event) => updateForm('classification', event.target.value as BookClassification)} data-testid="select-listing-classification">{BOOK_CLASSIFICATIONS.map((option) => <option key={option} value={option}>{option}</option>)}</select></div>}
        {form.kind === 'Resource' && <div className="form-field full"><label htmlFor="listing-pricing-mode">Resource offer</label><select id="listing-pricing-mode" value={form.resourcePricingMode} onChange={(event) => updateForm('resourcePricingMode', event.target.value as ResourcePricingMode)} data-testid="select-resource-pricing-mode"><option value="Rent">Rent by the week</option><option value="Sale">Sell at a fixed price</option></select></div>}
        <div className="form-field full"><label htmlFor="listing-price">{form.kind !== 'Resource' ? 'Service charge per hour (₹)' : form.resourcePricingMode === 'Sale' ? 'Fixed sale price (₹)' : 'Rent per week (₹)'}</label><input id="listing-price" type="number" min={form.kind === 'Resource' && form.resourcePricingMode === 'Sale' ? '0.01' : '40'} max={form.kind === 'Resource' && form.resourcePricingMode === 'Sale' ? undefined : '100'} step={form.kind === 'Resource' && form.resourcePricingMode === 'Sale' ? '0.01' : '1'} inputMode="decimal" required value={form.priceAmount} onChange={(event) => updateForm('priceAmount', event.target.value)} placeholder={form.kind === 'Resource' && form.resourcePricingMode === 'Sale' ? 'Fixed amount' : '40–100'} data-testid="input-listing-price" /><span className="field-hint">{form.kind !== 'Resource' ? 'Enter ₹40–₹100 for each hour of the service.' : form.resourcePricingMode === 'Sale' ? 'Enter a one-time fixed price for this product.' : 'Enter ₹40–₹100 for one week of rent.'}</span></div>
        <div className="form-field full"><label htmlFor="listing-description">A few useful details</label><textarea id="listing-description" value={form.description} onChange={(event) => updateForm('description', event.target.value)} placeholder="What should a neighbor know before reaching out?" data-testid="input-listing-description" /></div>
        <div className="form-field"><label htmlFor="listing-location">Where can it be found?</label><input id="listing-location" required value={form.location} onChange={(event) => updateForm('location', event.target.value)} placeholder="Library courtyard" data-testid="input-listing-location" /></div>
        <div className="form-field"><label htmlFor="listing-availability">When are you around?</label><input id="listing-availability" value={form.availability} onChange={(event) => updateForm('availability', event.target.value)} placeholder="Weekday evenings" data-testid="input-listing-availability" /></div>
        <div className="form-field full"><label htmlFor="listing-owner">Your name</label><input id="listing-owner" required value={form.owner} onChange={(event) => updateForm('owner', event.target.value)} placeholder="A name people can call you" data-testid="input-listing-owner" /></div>
      </div>
      <div className="modal-actions"><button type="button" className="button-secondary" onClick={() => setShowForm(false)} data-testid="button-cancel-form">Not yet</button><button type="submit" className="button-primary" data-testid="button-submit-listing"><Send size={14} /> Publish offer</button></div>
    </form></div>}
    {selected && <div className="modal-backdrop" role="presentation" onMouseDown={(event) => { if (event.target === event.currentTarget) setSelected(null); }}><div className="modal detail-modal" role="dialog" aria-label={`${selected.title} details`}>
      <div className="modal-head"><div><div className="detail-badges"><span className={`tag ${selected.kind === 'Skill' ? 'skill' : selected.kind === 'Time' ? 'time' : ''}`}>{selected.kind} · {selected.category}</span>{selected.classification && <span className="book-subject">{selected.classification}</span>}</div><h2 style={{ marginTop: 15 }}>{selected.title}</h2></div><button className="modal-close" onClick={() => setSelected(null)} aria-label="Close details" data-testid="button-close-details"><X size={16} /></button></div>
      <p className="detail-description">{selected.description}</p>
      <div className="detail-meta">
        <div><span>Where</span><strong><MapPin size={13} /> {selected.location}</strong></div>
        <div><span>When</span><strong><Clock3 size={13} /> {selected.availability}</strong></div>
        <div><span>Shared by</span><strong><span className="avatar" style={{ display: 'inline-grid', marginRight: 6 }}>{selected.initials}</span>{selected.owner}</strong></div>
        <div><span>{getListingPriceLabel(selected)}</span><strong>{getListingPriceValue(selected)}</strong></div>
        <div><span>Good next step</span><strong>Send a quick hello</strong></div>
      </div>
      <p className="payment-arrangement-note">Price shown only. This website does not collect payment.</p>
      <div className="modal-actions">
        <button className="button-secondary" onClick={() => toggleSaved(selected.id)} data-testid={`button-detail-save-${selected.id}`}><Bookmark size={14} fill={saved.has(selected.id) ? 'currentColor' : 'none'} /> {saved.has(selected.id) ? 'Saved' : 'Save for later'}</button>
        <button className="button-primary" onClick={() => setSelected(null)} data-testid="button-close-offer">Close</button>
      </div>
    </div></div>}
    {toast && <div className="toast" role="status" data-testid="status-toast">{toast}</div>}
  </div>;
}

export default App;