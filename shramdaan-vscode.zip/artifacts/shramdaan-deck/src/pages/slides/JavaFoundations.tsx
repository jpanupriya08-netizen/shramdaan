export default function JavaFoundations() {
  return (
    <div className="blueprint-slide relative h-screen w-screen overflow-hidden">
      <div className="blueprint-grid-fine" />
      <div className="blueprint-grid-major" />
      <div className="blueprint-frame" />
      <div className="blueprint-frame-inner" />

      <div
        className="relative flex h-full flex-col"
        style={{ padding: '7vh 7vw' }}
      >
        <div className="flex items-start justify-between">
          <div>
            <div
              className="blueprint-mono uppercase"
              style={{ fontSize: '1.5vw', letterSpacing: '0.2em', opacity: 0.55 }}
            >
              Section 04
            </div>
            <div
              className="blueprint-mono font-semibold"
              style={{ fontSize: '2vw', marginTop: '0.5vh' }}
            >
              IMPLEMENTATION MODEL
            </div>
          </div>
          <div className="text-right">
            <div
              className="blueprint-mono uppercase"
              style={{ fontSize: '1.5vw', letterSpacing: '0.2em', opacity: 0.55 }}
            >
              Ref No.
            </div>
            <div className="blueprint-mono" style={{ fontSize: '2vw', marginTop: '0.5vh' }}>
              JAVA-04X
            </div>
          </div>
        </div>

        <div className="flex flex-1 items-center" style={{ gap: '5vw' }}>
          <div className="blueprint-panel" style={{ width: '35vw', padding: '2.2vw' }}>
            <div className="blueprint-mono" style={{ fontSize: '1.5vw', color: 'var(--slide-primary)', letterSpacing: '0.12em' }}>
              RESOURCE.JAVA
            </div>
            <div className="blueprint-rule" style={{ marginTop: '1.7vh', marginBottom: '2vh' }} />
            <pre
              className="blueprint-mono"
              style={{
                whiteSpace: 'pre-wrap',
                fontSize: '1.7vw',
                lineHeight: 1.65,
                margin: 0,
                color: 'var(--slide-primary)',
              }}
            >
              {'class Resource {\n  String title;\n  String category;\n  String provider;\n  String location;\n  boolean available;\n}'}
            </pre>
            <div
              className="blueprint-mono"
              style={{
                borderTop: '1px solid rgba(255,255,255,0.2)',
                marginTop: '2vh',
                paddingTop: '1.8vh',
                fontSize: '1.7vw',
                color: 'var(--slide-accent)',
              }}
            >
              {'Scanner input = new Scanner(System.in);'}
            </div>
          </div>

          <div className="flex flex-1 flex-col" style={{ gap: '1.2vh' }}>
            <h1
              className="font-light"
              style={{
                fontSize: '3.4vw',
                lineHeight: 1,
                letterSpacing: '0.01em',
                margin: '0 0 1.3vh',
              }}
            >
              <span className="block">JAVA FOUNDATIONS</span>
              <span className="block">BEHIND THE PROJECT</span>
            </h1>
            <div className="blueprint-rule" style={{ marginBottom: '1.4vh' }} />
            <p style={{ fontSize: '2vw', lineHeight: 1.18, margin: 0 }}>
              Resource class stores title, category, provider, location, and availability
            </p>
            <p style={{ fontSize: '2vw', lineHeight: 1.18, margin: 0 }}>
              An array stores multiple Resource objects
            </p>
            <p style={{ fontSize: '2vw', lineHeight: 1.18, margin: 0 }}>
              Loops visit each resource on the board
            </p>
            <p style={{ fontSize: '2vw', lineHeight: 1.18, margin: 0 }}>
              Conditional statements filter matching and available offers
            </p>
            <p style={{ fontSize: '2vw', lineHeight: 1.18, margin: 0 }}>
              Methods handle searching, filtering, saving, and adding listings
            </p>
            <p style={{ fontSize: '2vw', lineHeight: 1.18, margin: 0 }}>
              Scanner can collect listing details in the Java implementation
            </p>
          </div>
        </div>

        <div
          className="blueprint-mono flex justify-between"
          style={{
            borderTop: '1px solid rgba(255,255,255,0.2)',
            paddingTop: '1.5vh',
            fontSize: '1.5vw',
            opacity: 0.55,
          }}
        >
          <span>SHRAMDAAN / IMPLEMENTATION MODEL</span>
          <span>04 / 05</span>
        </div>
      </div>
    </div>
  );
}