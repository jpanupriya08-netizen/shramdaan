export default function Problem() {
  return (
    <div className="blueprint-slide relative h-screen w-screen overflow-hidden">
      <div className="blueprint-grid-fine" />
      <div className="blueprint-grid-major" />
      <div className="blueprint-frame" />
      <div className="blueprint-frame-inner" />

      <div
        className="relative flex h-full flex-col"
        style={{ padding: '7vh 7vw' }}
      >
        <div className="flex items-start justify-between">
          <div>
            <div
              className="blueprint-mono uppercase"
              style={{ fontSize: '1.5vw', letterSpacing: '0.2em', opacity: 0.55 }}
            >
              Section 02
            </div>
            <div
              className="blueprint-mono font-semibold"
              style={{ fontSize: '2vw', marginTop: '0.5vh' }}
            >
              PROBLEM STATEMENT
            </div>
          </div>
          <div className="text-right">
            <div
              className="blueprint-mono uppercase"
              style={{ fontSize: '1.5vw', letterSpacing: '0.2em', opacity: 0.55 }}
            >
              Ref No.
            </div>
            <div className="blueprint-mono" style={{ fontSize: '2vw', marginTop: '0.5vh' }}>
              NEED-02X
            </div>
          </div>
        </div>

        <div className="flex flex-1 items-center" style={{ gap: '6vw' }}>
          <div style={{ width: '36vw' }}>
            <h1
              className="font-light"
              style={{
                fontSize: '5vw',
                lineHeight: 0.95,
                letterSpacing: '0.02em',
                margin: 0,
              }}
            >
              <span className="block">THE</span>
              <span className="block">PROBLEM</span>
            </h1>
            <div className="blueprint-rule" style={{ marginTop: '3vh' }} />
            <p
              style={{
                fontSize: '2.2vw',
                lineHeight: 1.3,
                color: 'var(--slide-primary)',
                margin: '2vh 0 0',
              }}
            >
              A local gap between what people have and what people need.
            </p>
          </div>

          <div
            className="grid flex-1"
            style={{
              gridTemplateColumns: '1fr 1fr',
              gap: '1.5vw',
            }}
          >
            <div className="blueprint-panel flex flex-col justify-between" style={{ padding: '2vw', minHeight: '22vh' }}>
              <div className="blueprint-mono" style={{ fontSize: '1.5vw', opacity: 0.55 }}>
                01 / UNUSED
              </div>
              <p style={{ fontSize: '2vw', lineHeight: 1.25, margin: 0 }}>
                Useful books, tools, and skills often go unused
              </p>
            </div>
            <div className="blueprint-panel flex flex-col justify-between" style={{ padding: '2vw', minHeight: '22vh' }}>
              <div className="blueprint-mono" style={{ fontSize: '1.5vw', opacity: 0.55 }}>
                02 / UNSEEN
              </div>
              <p style={{ fontSize: '2vw', lineHeight: 1.25, margin: 0 }}>
                Someone nearby may need exactly what another person already has
              </p>
            </div>
            <div className="blueprint-panel flex flex-col justify-between" style={{ padding: '2vw', minHeight: '22vh' }}>
              <div className="blueprint-mono" style={{ fontSize: '1.5vw', opacity: 0.55 }}>
                03 / DISCONNECTED
              </div>
              <p style={{ fontSize: '2vw', lineHeight: 1.25, margin: 0 }}>
                Informal sharing is difficult without one simple place to look
              </p>
            </div>
            <div className="blueprint-panel flex flex-col justify-between" style={{ padding: '2vw', minHeight: '22vh' }}>
              <div className="blueprint-mono" style={{ fontSize: '1.5vw', opacity: 0.55 }}>
                04 / UNCOORDINATED
              </div>
              <p style={{ fontSize: '2vw', lineHeight: 1.25, margin: 0 }}>
                Communities need an easy way to offer help and find help
              </p>
            </div>
          </div>
        </div>

        <div
          className="blueprint-mono flex justify-between"
          style={{
            borderTop: '1px solid rgba(255,255,255,0.2)',
            paddingTop: '1.5vh',
            fontSize: '1.5vw',
            opacity: 0.55,
          }}
        >
          <span>SHRAMDAAN / CONTEXT</span>
          <span>02 / 05</span>
        </div>
      </div>
    </div>
  );
}