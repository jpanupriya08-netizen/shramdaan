export default function Solution() {
  return (
    <div className="blueprint-slide relative h-screen w-screen overflow-hidden">
      <div className="blueprint-grid-fine" />
      <div className="blueprint-grid-major" />
      <div className="blueprint-frame" />
      <div className="blueprint-frame-inner" />

      <div
        className="relative flex h-full flex-col"
        style={{ padding: '7vh 7vw' }}
      >
        <div className="flex items-start justify-between">
          <div>
            <div
              className="blueprint-mono uppercase"
              style={{ fontSize: '1.5vw', letterSpacing: '0.2em', opacity: 0.55 }}
            >
              Section 03
            </div>
            <div
              className="blueprint-mono font-semibold"
              style={{ fontSize: '2vw', marginTop: '0.5vh' }}
            >
              PRODUCT FLOW
            </div>
          </div>
          <div className="text-right">
            <div
              className="blueprint-mono uppercase"
              style={{ fontSize: '1.5vw', letterSpacing: '0.2em', opacity: 0.55 }}
            >
              Ref No.
            </div>
            <div className="blueprint-mono" style={{ fontSize: '2vw', marginTop: '0.5vh' }}>
              FLOW-03X
            </div>
          </div>
        </div>

        <div className="flex flex-1 items-center" style={{ gap: '6vw' }}>
          <div style={{ width: '30vw' }}>
            <h1
              className="font-light"
              style={{
                fontSize: '4.8vw',
                lineHeight: 0.96,
                letterSpacing: '0.02em',
                margin: 0,
              }}
            >
              <span className="block">THE</span>
              <span className="block">SOLUTION</span>
            </h1>
            <div className="blueprint-rule" style={{ marginTop: '3vh' }} />
            <div className="blueprint-mono" style={{ fontSize: '1.7vw', lineHeight: 1.6, marginTop: '2vh', opacity: 0.7 }}>
              LIST
              <span style={{ padding: '0 0.7vw', color: 'var(--slide-accent)' }}>→</span>
              FIND
              <span style={{ padding: '0 0.7vw', color: 'var(--slide-accent)' }}>→</span>
              SHARE
            </div>
          </div>

          <div className="flex flex-1 flex-col" style={{ gap: '1.3vh' }}>
            <div className="blueprint-panel flex items-center" style={{ padding: '1.7vw 2vw', minHeight: '10vh' }}>
              <span className="blueprint-mono" style={{ color: 'var(--slide-accent)', fontSize: '1.7vw', width: '5vw' }}>01</span>
              <p style={{ fontSize: '2vw', lineHeight: 1.2, margin: 0 }}>
                A shared community noticeboard for resources, skills, and time
              </p>
            </div>
            <div className="blueprint-panel flex items-center" style={{ padding: '1.7vw 2vw', minHeight: '10vh' }}>
              <span className="blueprint-mono" style={{ color: 'var(--slide-accent)', fontSize: '1.7vw', width: '5vw' }}>02</span>
              <p style={{ fontSize: '2vw', lineHeight: 1.2, margin: 0 }}>
                Search listings by name, description, location, or provider
              </p>
            </div>
            <div className="blueprint-panel flex items-center" style={{ padding: '1.7vw 2vw', minHeight: '10vh' }}>
              <span className="blueprint-mono" style={{ color: 'var(--slide-accent)', fontSize: '1.7vw', width: '5vw' }}>03</span>
              <p style={{ fontSize: '2vw', lineHeight: 1.2, margin: 0 }}>
                Filter by category and availability
              </p>
            </div>
            <div className="blueprint-panel flex items-center" style={{ padding: '1.7vw 2vw', minHeight: '10vh' }}>
              <span className="blueprint-mono" style={{ color: 'var(--slide-accent)', fontSize: '1.7vw', width: '5vw' }}>04</span>
              <p style={{ fontSize: '2vw', lineHeight: 1.2, margin: 0 }}>
                Open an offer, save it for later, or show interest
              </p>
            </div>
            <div className="blueprint-panel flex items-center" style={{ padding: '1.7vw 2vw', minHeight: '10vh' }}>
              <span className="blueprint-mono" style={{ color: 'var(--slide-accent)', fontSize: '1.7vw', width: '5vw' }}>05</span>
              <p style={{ fontSize: '2vw', lineHeight: 1.2, margin: 0 }}>
                Add a new listing with a simple form
              </p>
            </div>
          </div>
        </div>

        <div
          className="blueprint-mono flex justify-between"
          style={{
            borderTop: '1px solid rgba(255,255,255,0.2)',
            paddingTop: '1.5vh',
            fontSize: '1.5vw',
            opacity: 0.55,
          }}
        >
          <span>SHRAMDAAN / PRODUCT FLOW</span>
          <span>03 / 05</span>
        </div>
      </div>
    </div>
  );
}