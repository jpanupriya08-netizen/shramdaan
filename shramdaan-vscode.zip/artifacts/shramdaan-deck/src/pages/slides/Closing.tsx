export default function Closing() {
  return (
    <div className="blueprint-slide relative h-screen w-screen overflow-hidden">
      <div className="blueprint-grid-fine" />
      <div className="blueprint-grid-major" />
      <div className="blueprint-frame" />
      <div className="blueprint-frame-inner" />

      <div
        className="relative flex h-full flex-col justify-between"
        style={{ padding: '7vh 7vw' }}
      >
        <div className="flex items-start justify-between">
          <div>
            <div
              className="blueprint-mono uppercase"
              style={{ fontSize: '1.5vw', letterSpacing: '0.2em', opacity: 0.55 }}
            >
              Section 05
            </div>
            <div
              className="blueprint-mono font-semibold"
              style={{ fontSize: '2vw', marginTop: '0.5vh' }}
            >
              COMMUNITY JOURNEY
            </div>
          </div>
          <div className="text-right">
            <div
              className="blueprint-mono uppercase"
              style={{ fontSize: '1.5vw', letterSpacing: '0.2em', opacity: 0.55 }}
            >
              Ref No.
            </div>
            <div className="blueprint-mono" style={{ fontSize: '2vw', marginTop: '0.5vh' }}>
              MATCH-05X
            </div>
          </div>
        </div>

        <div className="flex items-center" style={{ gap: '6vw' }}>
          <div style={{ width: '39vw' }}>
            <h1
              className="font-light"
              style={{
                fontSize: '4.5vw',
                lineHeight: 0.98,
                letterSpacing: '0.01em',
                margin: 0,
              }}
            >
              <span className="block">FROM AN</span>
              <span className="block">UNUSED ITEM</span>
              <span className="block">TO A USEFUL MATCH</span>
            </h1>
            <div className="blueprint-rule" style={{ marginTop: '3vh' }} />
          </div>

          <div className="flex flex-1 flex-col" style={{ gap: '1.35vh' }}>
            <div className="blueprint-panel" style={{ padding: '1.6vw 2vw' }}>
              <p style={{ fontSize: '2vw', lineHeight: 1.2, margin: 0 }}>
                A student lists an extra textbook, bike, skill, or time
              </p>
            </div>
            <div className="blueprint-panel" style={{ padding: '1.6vw 2vw' }}>
              <p style={{ fontSize: '2vw', lineHeight: 1.2, margin: 0 }}>
                Another student searches the shared board
              </p>
            </div>
            <div className="blueprint-panel" style={{ padding: '1.6vw 2vw' }}>
              <p style={{ fontSize: '2vw', lineHeight: 1.2, margin: 0 }}>
                Clear location and availability make the next step simple
              </p>
            </div>
            <div className="blueprint-panel" style={{ padding: '1.6vw 2vw' }}>
              <p style={{ fontSize: '2vw', lineHeight: 1.2, margin: 0 }}>
                Shramdaan turns unused capacity into community support
              </p>
            </div>
            <div className="blueprint-panel" style={{ padding: '1.6vw 2vw', borderColor: 'rgba(243,200,75,0.6)' }}>
              <p style={{ fontSize: '2vw', lineHeight: 1.2, margin: 0, color: 'var(--slide-accent)' }}>
                Future improvement: keep listings and saved offers after refresh
              </p>
            </div>
          </div>
        </div>

        <div
          className="flex items-end justify-between"
          style={{
            borderTop: '1px solid rgba(255,255,255,0.22)',
            paddingTop: '1.8vh',
          }}
        >
          <div>
            <div
              className="blueprint-mono uppercase"
              style={{ fontSize: '1.5vw', letterSpacing: '0.15em', opacity: 0.45 }}
            >
              Closing Note
            </div>
            <div
              className="blueprint-mono"
              style={{ fontSize: '1.8vw', marginTop: '0.5vh', color: 'var(--slide-primary)' }}
            >
              COMMUNITY SUPPORT, MAPPED
            </div>
          </div>
          <div className="text-right">
            <div
              className="blueprint-mono uppercase"
              style={{ fontSize: '1.5vw', letterSpacing: '0.15em', opacity: 0.45 }}
            >
              Page
            </div>
            <div className="blueprint-mono" style={{ fontSize: '1.8vw', marginTop: '0.5vh' }}>
              05 / 05
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}