export default function Title() {
  return (
    <div className="blueprint-slide relative h-screen w-screen overflow-hidden">
      <div className="blueprint-grid-fine" />
      <div className="blueprint-grid-major" />
      <div className="blueprint-frame" />
      <div className="blueprint-frame-inner" />

      <div
        className="relative flex h-full flex-col justify-between"
        style={{ padding: '7vh 7vw' }}
      >
        <div className="flex items-start justify-between">
          <div>
            <div
              className="blueprint-mono uppercase"
              style={{
                fontSize: '1.5vw',
                letterSpacing: '0.2em',
                opacity: 0.58,
              }}
            >
              Drawing No.
            </div>
            <div
              className="blueprint-mono font-semibold"
              style={{ fontSize: '2vw', marginTop: '0.5vh' }}
            >
              SHR-DCK-001
            </div>
          </div>
          <div className="text-right">
            <div
              className="blueprint-mono uppercase"
              style={{
                fontSize: '1.5vw',
                letterSpacing: '0.2em',
                opacity: 0.58,
              }}
            >
              Project
            </div>
            <div
              className="blueprint-mono"
              style={{ fontSize: '2vw', marginTop: '0.5vh' }}
            >
              JAVA PROJECT
            </div>
          </div>
        </div>

        <div>
          <div
            className="blueprint-mono uppercase"
            style={{
              fontSize: '1.5vw',
              letterSpacing: '0.3em',
              opacity: 0.58,
              marginBottom: '2vh',
            }}
          >
            Project Title
          </div>
          <h1
            className="font-light tracking-tight"
            style={{
              fontSize: '6vw',
              lineHeight: 0.9,
              letterSpacing: '0.035em',
              margin: 0,
            }}
          >
            SHRAMDAAN
          </h1>
          <div className="blueprint-rule" style={{ marginTop: '2.5vh' }} />
          <p
            style={{
              fontSize: '2.2vw',
              fontWeight: 400,
              lineHeight: 1.35,
              margin: '1.8vh 0 0',
              maxWidth: '49vw',
              color: 'var(--slide-primary)',
            }}
          >
            Community Resource &amp; Skill Mapper
          </p>
          <p
            className="blueprint-mono"
            style={{
              fontSize: '1.8vw',
              lineHeight: 1.4,
              margin: '1vh 0 0',
              opacity: 0.7,
            }}
          >
            Give a little. Find a lot.
          </p>
        </div>

        <div
          className="flex justify-between"
          style={{
            borderTop: '1px solid rgba(255,255,255,0.22)',
            paddingTop: '1.8vh',
          }}
        >
          <div>
            <div
              className="blueprint-mono uppercase"
              style={{
                fontSize: '1.5vw',
                letterSpacing: '0.15em',
                opacity: 0.45,
              }}
            >
              Prepared By
            </div>
            <div
              className="blueprint-mono"
              style={{ fontSize: '1.8vw', marginTop: '0.5vh' }}
            >
              COMMUNITY PROJECT
            </div>
          </div>
          <div>
            <div
              className="blueprint-mono uppercase"
              style={{
                fontSize: '1.5vw',
                letterSpacing: '0.15em',
                opacity: 0.45,
              }}
            >
              Classification
            </div>
            <div
              className="blueprint-mono"
              style={{ fontSize: '1.8vw', marginTop: '0.5vh' }}
            >
              PROJECT PRESENTATION
            </div>
          </div>
          <div>
            <div
              className="blueprint-mono uppercase"
              style={{
                fontSize: '1.5vw',
                letterSpacing: '0.15em',
                opacity: 0.45,
              }}
            >
              Scale
            </div>
            <div
              className="blueprint-mono"
              style={{ fontSize: '1.8vw', marginTop: '0.5vh' }}
            >
              1:1
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}